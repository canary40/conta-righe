chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "countLines") {
    const selection = window.getSelection();
    if (selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      const rect = range.getBoundingClientRect();
      const computedStyle = window.getComputedStyle(range.startContainer.parentNode);

      // Ottieni l'altezza di riga dal nodo contenente il testo selezionato
      let lineHeight = parseFloat(computedStyle.lineHeight);

      // Se non è possibile ottenere l'altezza di riga, usa un valore di fallback
      if (isNaN(lineHeight) || lineHeight <= 0) {
        const fontSize = parseFloat(computedStyle.fontSize) || 16; // Font size medio
        lineHeight = fontSize * 1.2; // Fallback basato su proporzione
      }

      // Calcola il numero di righe selezionate
      if (rect.height > 0) {
        const lines = Math.round(rect.height / lineHeight);

        // Mostra una finestra di dialogo con il risultato
        alert(`Hai evidenziato circa ${lines} righe.`);
      } else {
        alert("Non è stato possibile calcolare il numero di righe. Prova a selezionare un'altra area di testo.");
      }
    } else {
      alert("Seleziona del testo prima di usare questa funzione.");
    }
  }
});
