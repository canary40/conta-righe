chrome.runtime.onInstalled.addListener(() => {
  // Aggiunge l'opzione al menu contestuale
  chrome.contextMenus.create({
    id: "count-lines",
    title: "Conta righe evidenziate",
    contexts: ["selection"]
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "count-lines") {
    // Invia un messaggio alla pagina attiva per contare le righe
    chrome.tabs.sendMessage(tab.id, { action: "countLines" });
  }
});
